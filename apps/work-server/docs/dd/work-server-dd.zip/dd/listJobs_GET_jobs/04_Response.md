---
title: "Response"
order: 4
dd_id: "listJobs"
api_name: "jobs.view.getJobs"
source_workbook: "DD_API_Template(1).xlsx"
source_sheet: "2.Response"
status: "Draft — Ready for Review"
---
# Response

## Format

Mọi success response dùng `successResponse`; mọi lỗi đi qua `errorResponse`/centralized exception handler.

| Field | Type | Example | Description | Source |
| ---: | --- | --- | --- | --- |
| success | boolean | true | Luôn true ở success response. | successResponse |
| businessCode | string | `JOBS_LOADED` | Business code do view/system route trả về. | successResponse |
| message | string | Đã tải danh sách việc làm. | Message source-confirmed. | successResponse |
| data | array | route-specific | jsonSafe chuyển BigInt/Date trước khi serialize. | view result |
| meta | object | {"page": 1, "limit": 6, "total": 1, "totalPages": 1} | Pagination hoặc object rỗng. | successResponse |
| traceId | UUID string | 11111111-1111-4111-8111-111111111111 | Lấy từ AsyncLocalStorage/request trace context. | traceMiddleware |
| data[].id | number sau jsonSafe | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].ten_vi_tri | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].phong_ban | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].cap_bac | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].bao_cao_cho | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].nhiem_vu | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].trinh_do | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].kinh_nghiem | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].ky_nang | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].ky_nang_mem | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].uu_tien | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].muc_luong | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].phuc_loi | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].moi_truong | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].dia_diem | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].thoi_gian | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].han_nop | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].cach_ung_tuyen | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].mo_ta | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].ten_cong_ty | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].nganh | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].ngay_tao | string ISO-8601 sau jsonSafe | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].doanhnghiep_id | number sau jsonSafe | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |
| data[].avt | string \| null | source value | jobPublicSelect field. | jobs view/query and jobPublicSelect |

## Ví dụ thành công

```json
{
  "success": true,
  "businessCode": "JOBS_LOADED",
  "message": "Đã tải danh sách việc làm.",
  "data": [
    {
      "id": 10,
      "ten_vi_tri": "Backend Engineer",
      "phong_ban": null,
      "cap_bac": null,
      "bao_cao_cho": null,
      "nhiem_vu": null,
      "trinh_do": null,
      "kinh_nghiem": null,
      "ky_nang": null,
      "ky_nang_mem": null,
      "uu_tien": null,
      "muc_luong": null,
      "phuc_loi": null,
      "moi_truong": null,
      "dia_diem": "Hanoi",
      "thoi_gian": null,
      "han_nop": null,
      "cach_ung_tuyen": null,
      "mo_ta": null,
      "ten_cong_ty": "Test Business",
      "nganh": null,
      "ngay_tao": "2026-09-18T00:00:00.000Z",
      "doanhnghiep_id": 2,
      "avt": null
    }
  ],
  "meta": {
    "page": 1,
    "limit": 6,
    "total": 1,
    "totalPages": 1
  },
  "traceId": "11111111-1111-4111-8111-111111111111"
}
```

## Ví dụ lỗi

```json
{
  "success": false,
  "businessCode": "INVALID_REQUEST",
  "message": "Request không hợp lệ.",
  "data": null,
  "meta": {
    "fieldErrors": [
      {
        "field": "email",
        "code": "invalid_string",
        "message": "Email không hợp lệ."
      }
    ]
  },
  "traceId": "11111111-1111-4111-8111-111111111111"
}
```

## Serialization and trace

- `BigInt` được serialize thành number bởi `jsonSafe`.
- `Date` được serialize thành ISO-8601 string bởi `jsonSafe`.
- `X-Trace-Id` response header bằng `traceId` trong body.
- `meta.fieldErrors` chỉ có khi centralized mapper nhận `ZodError` có field issues.


---
## Phụ lục đối chiếu nguồn Excel
- Workbook nguồn: `DD_API_Template(1).xlsx`
- Sheet nguồn: `2.Response`
- Dimension: `A2:BR45`
- Trạng thái: `visible`
- Số ô có dữ liệu/công thức: `52`
- Số vùng merge: `15`

<details>
<summary>Danh sách vùng merge</summary>

- `B14:C15`
- `B16:C16`
- `B21:C21`
- `B22:BA22`
- `B23:C23`
- `B24:C24`
- `D14:S14`
- `T14:AK14`
- `AL14:BA15`
- `B20:C20`
- `B17:C17`
- `B18:C18`
- `T18:AB18`
- `AC18:AK18`
- `B19:BA19`

</details>

<details>
<summary>Bản ghi từng ô có dữ liệu hoặc công thức</summary>

| Hàng | Ô | Giá trị nguồn | Công thức nguồn |
|---:|---|---|---|
| 2 | `B2` | Giải thích |  |
| 4 | `C4` | Giá trị trả về khi call API |  |
| 9 | `B9` | Format |  |
| 9 | `L9` | JSON |  |
| 10 | `B10` | Code ký tự |  |
| 10 | `L10` | UTF-8 |  |
| 11 | `B11` | Content-Type |  |
| 11 | `L11` | application/json |  |
| 14 | `B14` | No |  |
| 14 | `D14` | Response item name |  |
| 14 | `T14` | Refer DB |  |
| 14 | `AL14` | Remarks |  |
| 15 | `D15` | Tên logic |  |
| 15 | `L15` | Tên vật lý |  |
| 15 | `T15` | Table nguồn get |  |
| 15 | `AC15` | Field nguồn get |  |
| 16 | `B16` | 1 |  |
| 16 | `D16` | HTTP Status |  |
| 16 | `L16` | HTTPStatus |  |
| 16 | `AL16` | Thành công: 200/ Phát sinh lỗi: 500/ Validate lỗi: 400 |  |
| 17 | `B17` | 2 |  |
| 17 | `D17` | Status |  |
| 17 | `L17` | status |  |
| 17 | `AL17` | Thành công: 1/phát sinh error: 2 |  |
| 18 | `B18` | 3 |  |
| 18 | `D18` | Nội dung response |  |
| 18 | `L18` | response |  |
| 19 | `B19` | Trường hợp thành công |  |
| 20 | `B20` | 3.1 |  |
| 21 | `B21` | 3.2 |  |
| 22 | `B22` | Các trường hợp lỗi của API |  |
| 23 | `B23` | 3.1 |  |
| 23 | `D23` | Error code |  |
| 23 | `M23` | error_code |  |
| 24 | `B24` | 3.2 |  |
| 24 | `D24` | Error Message id |  |
| 24 | `M24` | error_message_id |  |
| 26 | `B26` | Ví dụ |  |
| 27 | `M27` | Trường hợp thành công |  |
| 28 | `N28` | { |  |
| 29 | `O29` |   "status": 1, |  |
| 30 | `O30` |   "response":{ |  |
| 33 | `O33` | } |  |
| 34 | `N34` | } |  |
| 36 | `M36` | Trường hợp lỗi |  |
| 37 | `N37` | { |  |
| 38 | `O38` | "status" : 2 , |  |
| 39 | `O39` | "response" : {  |  |
| 40 | `P40` | "error_code" : "9999", |  |
| 41 | `P41` | "error_message_id" : "DLG000000" |  |
| 42 | `O42` |  } |  |
| 43 | `N43` |  } |  |

</details>
